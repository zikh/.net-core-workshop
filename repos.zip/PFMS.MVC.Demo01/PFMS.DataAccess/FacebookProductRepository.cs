﻿using PFMS.Domain;
using System.Collections.Generic;

namespace PFMS.DataAccess
{
    public class FacebookProductRepository : IProductRepository
    {
        public List<Product> GetProducts()
        {
            return new List<Product>
            {
                new Product {Id = 1, Name = "FaceBook A", Price = 10M },
                new Product {Id = 2, Name = "FaceBook B", Price = 20M },
                new Product {Id = 3, Name = "FaceBook C", Price = 30M },
                new Product {Id = 4, Name = "FaceBook D", Price = 30M },
                new Product {Id = 5, Name = "FaceBook E", Price = 30M },
                new Product {Id = 6, Name = "FaceBook F", Price = 30M },
                new Product {Id = 7, Name = "FaceBook G", Price = 30M },
                new Product {Id = 8, Name = "FaceBook G", Price = 30M },
            };
        }
    }
}
