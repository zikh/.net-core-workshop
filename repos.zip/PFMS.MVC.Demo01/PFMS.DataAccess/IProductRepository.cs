﻿using PFMS.Domain;
using System.Collections.Generic;

namespace PFMS.DataAccess
{
    public interface IProductRepository
    {
        List<Product> GetProducts();
    }
}
