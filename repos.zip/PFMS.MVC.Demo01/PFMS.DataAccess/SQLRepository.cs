﻿using PFMS.Domain;
using System.Collections.Generic;

namespace PFMS.DataAccess
{
    public class SQLRepository : IProductRepository
    {
        public string ConnectionString { get; set; }
        List<Product> _products;

        public SQLRepository()
        {
            _products = new List<Product>
            {
                new Product {Id = 1, Name = "A", Price = 10M },
                new Product {Id = 2, Name = "B", Price = 20M },
                new Product {Id = 3, Name = "C", Price = 30M },
            };
        }

        public List<Product> GetProducts()
        {
            return _products;
        }
    }
}
