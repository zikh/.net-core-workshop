﻿using PFMS.Domain;

namespace PFMS.MVC.Demo01.Interfaces
{
    public class DiwaliSale : IBusinessPolicy
    {
        public bool IsProductOnSale(Product product)
        {
            return product.Id % 2 == 0;
        }
    }
}
