﻿using PFMS.Domain;

namespace PFMS.MVC.Demo01.Interfaces
{
    public interface IBusinessPolicy
    {
        bool IsProductOnSale(Product product);
    }
}
