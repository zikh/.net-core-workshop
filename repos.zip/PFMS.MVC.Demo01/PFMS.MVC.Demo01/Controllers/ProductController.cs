﻿using Microsoft.AspNetCore.Mvc;
using PFMS.DataAccess;
using PFMS.MVC.Demo01.Interfaces;
using PFMS.MVC.Demo01.Views.Product;
using System.Collections.Generic;

namespace PFMS.MVC.Demo01.Controllers
{

    public class ProductController : Controller
    {
        IProductRepository _productRepository;
        IBusinessPolicy _policy;

        public ProductController(IProductRepository productRepository, IBusinessPolicy policy)
        {
            _productRepository = productRepository;
            _policy = policy;
        }

        public IActionResult Index()
        {
            var products = _productRepository.GetProducts();
            var productsVM = new List<ProductViewModel>();
            foreach (var p in products)
            {
                productsVM.Add(new ProductViewModel
                {
                    Id = p.Id,
                    Name = p.Name,
                    Price = p.Price,
                    IsOnSale = _policy.IsProductOnSale(p)
                });
            }
            return View(null);
        }
    }
}