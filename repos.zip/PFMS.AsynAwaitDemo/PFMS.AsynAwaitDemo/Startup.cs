﻿using System;
using System.Threading.Tasks;

namespace PFMS.AsynAwaitDemo
{
    public class Startup
    {
        static object printLock = new object();
        public async Task Run()
        {
            var tasks = new Task[10];
            for (int i = 0; i < 10; i++)
            {
                await Task.Run(() => Console.WriteLine("hello"));
            }
            await Task.Delay(1000);
        }

        void PrintData(int count)
        {
            Console.WriteLine(count);
        }
    }
}
