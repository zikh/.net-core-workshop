﻿namespace PFMS.SOLIDDemo
{
    internal interface IMessageReader
    {
        string ReadMessage();
    }
}