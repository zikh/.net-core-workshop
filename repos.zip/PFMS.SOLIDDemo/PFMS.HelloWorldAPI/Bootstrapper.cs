﻿using System;

namespace PFMS.HelloWorldAPI
{
    class Bootstrapper
    {
        public static void Bootstrapper()
        {
            _container.RegisterType<IMessageReader, ConsoleMessageReader>();
            _container.RegisterType<IMessageWriter, FacebookMessageWriter>();
            _container.RegisterType<Startup, Startup>();
        }

    }
}
