﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PFMS.SOLIDDemo
{
    class FacebookMessageWriter : IMessageWriter
    {
        public void WriteMessage(string message)
        {
            Console.WriteLine("Connted to facebook");
            Console.WriteLine(message);
        }
    }
}
