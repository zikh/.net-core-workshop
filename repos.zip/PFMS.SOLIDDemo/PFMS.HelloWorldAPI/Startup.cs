﻿namespace PFMS.SOLIDDemo
{
    class Startup
    {
        IMessageReader _messageReader;
        IMessageWriter _messageWriter;
        public Startup(IMessageReader messageReader, IMessageWriter messageWriter)
        {
            _messageReader = messageReader;
            _messageWriter = messageWriter;
        }
        public void Run()
        {
            _messageWriter.WriteMessage(_messageReader.ReadMessage());
        }
    }
}
