﻿using System;

namespace PFMS.SOLIDDemo
{
    class ConsoleMessageWriter : IMessageWriter
    {
        public void WriteMessage(string message)
        {
            Console.WriteLine(message);
        }
    }
}
