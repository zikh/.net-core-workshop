﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PFMS.SOLIDDemo
{
    class ConsoleMessageReader : IMessageReader
    {
        public string ReadMessage()
        {
            return "Hello, world!";
        }
    }
}
