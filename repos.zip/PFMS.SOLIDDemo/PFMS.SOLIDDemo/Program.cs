﻿using Unity;

namespace PFMS.SOLIDDemo
{
    static class Bootstrapper
    {
        public static IUnityContainer Container { get; set; }
        static Bootstrapper()
        {
            Container = new UnityContainer();
            Container.RegisterType<IMessageReader, ConsoleMessageReader>();
            Container.RegisterType<IMessageWriter, FacebookMessageWriter>();
            Container.RegisterType<Startup, Startup>();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Bootstrapper
                .Container
                .Resolve<Startup>()
                .Run();
        }
    }
}
