﻿namespace PFMS.SOLIDDemo
{
    public interface IMessageReader
    {
        string ReadMessage();
    }
}