﻿namespace PFMS.StringUtilities
{
    public class PfmsString
    {
        string _input;
        public PfmsString(string input)
        {
            _input = input;
            if (_input == null)
                _input = string.Empty;
        }

        public int Length()
        {
            var count = 0;
            foreach (var character in _input)
            {
                ++count;
            }
            return count;
        }
        public int LengthOfLowerCaseCharacters()
        {
            var count = 0;
            foreach (var character in _input)
            {
                if (char.IsLower(character))
                    ++count;
            }
            return count;
        }
    }
}
