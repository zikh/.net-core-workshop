﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace PFMS.StringUtilities.Tests
{
    [TestClass]
    public class PfmsStringTests
    {
        [TestMethod]
        public void ShouldReturn3ForInputStringZia()
        {
            // Arrange
            var pfmsString = new PfmsString("Zia");
            var expectedLength = 3;

            // Act
            var actualLength = pfmsString.Length();

            // Assert
            Assert.AreEqual(expectedLength, actualLength);
        }

        [TestMethod]
        public void ShouldReturn5forInputStringVijay()
        {
            // Arrange
            var pfmsString = new PfmsString("Vijay");
            var expectedLength = 5;

            // Act
            var actualLength = pfmsString.Length();

            // Assert
            Assert.AreEqual(expectedLength, actualLength);
        }

        [TestMethod]
        public void ShouldReturnZeroWhenInputStringIsNullorEmpty()
        {
            // Arrange
            var pfmsString = new PfmsString(null);
            var expectedLength = 0;

            // Act
            var actualLength = pfmsString.Length();

            // Assert
            Assert.AreEqual(expectedLength, actualLength);
        }

        [TestMethod]
        public void ShouldReturn2WhenInputStringIsZiaCountingSmallLetters()
        {
            // Arrange
            var pfmsString = new PfmsString("Zia");
            var expectedLength = 2;

            // Act
            var actualLength = pfmsString.LengthOfLowerCaseCharacters();

            // Assert
            Assert.AreEqual(expectedLength, actualLength);
        }
    }
}
