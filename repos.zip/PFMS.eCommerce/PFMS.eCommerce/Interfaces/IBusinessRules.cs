﻿using PFMS.eCommerce.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PFMS.eCommerce.Interfaces
{
    public interface IBusinessRules
    {
        bool EligibleProducts(Product product);
    }
}
