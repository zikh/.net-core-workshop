﻿using PFMS.eCommerce.Models;
using System;
using System.Collections.Generic;

namespace PFMS.eCommerce.Interfaces
{
    public class ProductRepository : IProductRepository
    {
        public IReadOnlyList<Product> GetProducts()
        {
            return new List<Product> {
                new Product { Id= 1, Name = "Product 1", Price = 10.20M},
                new Product { Id= 2, Name = "Product 1", Price = 20.20M},
                new Product { Id= 3, Name = "Product 1", Price = 30.20M},
                new Product { Id= 4, Name = "Product 1", Price = 40.20M},
                new Product { Id= 5, Name = "Product 1", Price = 50.20M},
            };
        }
    }
}
