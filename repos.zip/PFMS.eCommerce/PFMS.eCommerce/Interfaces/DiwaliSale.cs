﻿using PFMS.eCommerce.Models;

namespace PFMS.eCommerce.Interfaces
{
    public class DiwaliSale : IBusinessRules
    {
        public bool EligibleProducts(Product product)
        {
            return product.Id % 2 == 0;
        }
    }
}
