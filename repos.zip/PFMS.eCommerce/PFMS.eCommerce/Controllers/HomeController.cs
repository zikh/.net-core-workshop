﻿using Microsoft.AspNetCore.Mvc;
using PFMS.eCommerce.Interfaces;
using PFMS.eCommerce.Models;
using PFMS.eCommerce.Views.Home.ViewModels;
using System.Collections.Generic;
using System.Diagnostics;

namespace PFMS.eCommerce.Controllers
{
    public class HomeController : Controller
    {
        IProductRepository _repository;
        IBusinessRules _businessRules;

        public HomeController(IProductRepository repository, IBusinessRules businessRules)
        {
            _repository = repository;
            _businessRules = businessRules;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult GetProducts()
        {
            var result = _repository.GetProducts();
            var resultVM = new List<ResultsViewModel>();

            foreach (var item in result)
            {
                resultVM.Add(new ResultsViewModel
                {
                    Id = item.Id,
                    Name = item.Name,
                    Price = item.Price,
                    IsOnSale = _businessRules.EligibleProducts(item)
                });
            }

            return View(resultVM);
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
